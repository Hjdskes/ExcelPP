package com.awesome.excelpp.junit.math;

import org.junit.Test;

import junit.framework.TestCase;

public class IsLogicTest extends TestCase {

	@Test
	public void test() {
		
	}

}

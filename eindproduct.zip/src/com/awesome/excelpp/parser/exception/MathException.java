package com.awesome.excelpp.parser.exception;


public class MathException extends ParserException {
	private static final long serialVersionUID = 1L;
}

package com.awesome.excelpp.parser.exception;

public class RecursionException extends Exception {
	private static final long serialVersionUID = 1L;
}
